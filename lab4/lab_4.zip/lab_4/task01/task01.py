import random as rd
import math

def random_points(radius, x_center, y_center):
    pass
